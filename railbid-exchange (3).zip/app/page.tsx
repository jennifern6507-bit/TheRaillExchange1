import Link from 'next/link'

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-12">
      <section className="grid md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-extrabold">The Rail Track Bidding Marketplace</h1>
          <p className="mt-4 text-lg text-gray-700">Post track projects, get competitive bids from verified contractors, compare pricing, and manage documents — all in one place.</p>
          <div className="mt-6 flex gap-3">
            <Link href="/projects/new" className="px-5 py-3 bg-indigo-600 text-white rounded">Post a Project</Link>
            <Link href="/pricing" className="px-5 py-3 border rounded">See Pricing</Link>
          </div>
        </div>
        <div className="bg-white rounded shadow p-6">
          <h3 className="font-semibold">How it works</h3>
          <ol className="list-decimal list-inside mt-3 text-gray-700">
            <li>Owner posts project (upload drone maps & CAD)</li>
            <li>Contractors in region receive alerts & bid</li>
            <li>Owner compares bids with our AI cost estimate</li>
            <li>Award project, optionally pay via the platform</li>
          </ol>
        </div>
      </section>
    </main>
  )
}
