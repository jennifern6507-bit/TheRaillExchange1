import './globals.css'
import React from 'react'

export const metadata = {
  title: 'RailBid Exchange',
  description: 'Track bidding marketplace for rail infrastructure'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <div className="min-h-screen bg-neutral-50">
          <header className="bg-white shadow">
            <div className="container mx-auto px-4 py-4 flex items-center justify-between">
              <div className="text-2xl font-bold">RailBid Exchange™</div>
              <nav className="space-x-4">
                <a href="/projects" className="hover:underline">Projects</a>
                <a href="/contractors" className="hover:underline">Contractors</a>
                <a href="/pricing" className="hover:underline">Pricing</a>
              </nav>
            </div>
          </header>
          <main>{children}</main>
          <footer className="mt-12 bg-white py-6">
            <div className="container mx-auto text-center text-sm text-gray-600">© {new Date().getFullYear()} RailBid Exchange</div>
          </footer>
        </div>
      </body>
    </html>
  )
}
