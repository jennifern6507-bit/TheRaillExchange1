# RailBid Exchange

Next.js + Prisma + Stripe starter for the Rail Track Bidding Marketplace.

## Quick start

1. Copy files into a new GitHub repo.
2. Create a `.env` from `.env.example` and fill values.
3. Install dependencies: `npm install`.
4. Run migrations: `npx prisma migrate dev --name init`.
5. Run dev: `npm run dev`.

## Deploy
Deploy to Vercel. Set environment variables in Vercel dashboard. Configure Stripe webhook to `https://your-deploy-url.vercel.app/api/stripe/webhook`.
