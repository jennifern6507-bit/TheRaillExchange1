import { prisma } from "../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const userId = req.headers["x-user-id"] as string | undefined;
  if (!userId) return res.status(401).json({ error: "unauthorized" });

  const data = req.body;
  // prisma.shipper model not in schema; this endpoint is a pattern placeholder
  res.status(200).json({ message: "shipper profile endpoint - implement schema" });
}
