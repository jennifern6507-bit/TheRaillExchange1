import { prisma } from "../../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  if (req.method === "POST") {
    const { question, askedById } = req.body;
    if (!question || !askedById) return res.status(400).json({ error: "missing fields" });
    const qa = await prisma.projectQA.create({
      data: { projectId: id as string, question, askedById },
    });
    return res.status(201).json(qa);
  }
  res.setHeader("Allow", ["POST"]);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
