import { prisma } from "../../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { id } = req.query;
  if (req.method === "GET") {
    const bids = await prisma.bid.findMany({
      where: { projectId: id as string },
      include: { contractor: true },
      orderBy: { createdAt: "asc" },
    });
    return res.status(200).json(bids);
  }
  res.setHeader("Allow", ["GET"]);
  res.status(405).end(`Method ${req.method} Not Allowed`);
}
