import { NextApiRequest, NextApiResponse } from "next"
import { prisma } from "../../lib/prisma"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === "GET") {
    const projects = await prisma.project.findMany({
      where: { status: "OPEN" },
      include: { owner: { select: { name: true } }, bids: true },
      orderBy: { createdAt: "desc" },
    })
    return res.status(200).json(projects)
  }

  if (req.method === "POST") {
    const { ownerId, title, description, location, region, budgetMin, budgetMax } = req.body
    const project = await prisma.project.create({
      data: {
        ownerId,
        title,
        description,
        location,
        region,
        budgetMin,
        budgetMax
      }
    })

    // Notify contractors in region (basic pattern)
    try {
      const contractors = await prisma.contractor.findMany({ where: { verified: true, regions: { has: region } } })
      // TODO: enqueue/send email or push notifications to contractors
    } catch (e) {
      console.error('Error notifying contractors', e)
    }

    return res.status(201).json(project)
  }

  res.setHeader('Allow', ['GET','POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}
