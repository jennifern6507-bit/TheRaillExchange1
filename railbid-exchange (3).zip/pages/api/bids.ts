import { NextApiRequest, NextApiResponse } from "next"
import { prisma } from "../../lib/prisma"

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const { projectId, contractorId, amount, notes } = req.body
    if (!projectId || !amount || !contractorId) return res.status(400).json({ error: 'Missing fields' })

    const bid = await prisma.bid.create({
      data: { projectId, contractorId, amount, notes }
    })
    return res.status(201).json(bid)
  }
  res.setHeader('Allow', ['POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}
