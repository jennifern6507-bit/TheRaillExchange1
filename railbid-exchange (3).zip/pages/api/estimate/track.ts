import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).end();

  const { trackFeet = 0, tieCount = 0, turnoutCount = 0, location = "normal" } = req.body;

  const cost =
    trackFeet * 85 +
    tieCount * 42 +
    turnoutCount * 38000 +
    (location === "remote" ? 5000 : 0);

  res.status(200).json({
    estimatedCost: cost,
    low: Math.round(cost * 0.85),
    high: Math.round(cost * 1.25),
    notes: "AI model integration pending — using baseline rail cost factors.",
  });
}
