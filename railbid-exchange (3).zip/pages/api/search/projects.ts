import { prisma } from "../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const q = (req.query.q as string) || "";
  const state = (req.query.state as string) || undefined;
  const workType = (req.query.workType as string) || undefined;

  const projects = await prisma.project.findMany({
    where: {
      AND: [
        q
          ? {
              OR: [
                { title: { contains: q, mode: "insensitive" } },
                { description: { contains: q, mode: "insensitive" } },
              ],
            }
          : undefined,
        state ? { region: state } : undefined,
        workType ? undefined : undefined,
      ].filter(Boolean),
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  res.status(200).json(projects);
}
