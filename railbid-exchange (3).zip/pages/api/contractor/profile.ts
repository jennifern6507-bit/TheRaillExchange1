import { prisma } from "../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const userId = req.headers["x-user-id"] as string | undefined;
  if (!userId) return res.status(401).json({ error: "unauthorized" });

  const data = req.body;
  const contractor = await prisma.contractor.upsert({
    where: { userId },
    create: { userId, ...data },
    update: data,
  });
  res.status(200).json(contractor);
}
