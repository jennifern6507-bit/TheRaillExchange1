import { prisma } from "../../../lib/prisma";
import { NextApiRequest, NextApiResponse } from "next";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const q = (req.query.q as string) || "";
  const state = (req.query.state as string) || undefined;
  const service = (req.query.service as string) || undefined;

  const contractors = await prisma.contractor.findMany({
    where: {
      AND: [
        q
          ? {
              OR: [
                { companyName: { contains: q, mode: "insensitive" } }
              ],
            }
          : undefined,
        state ? { regions: { has: state } } : undefined,
        service ? { services: { has: service } } : undefined,
      ].filter(Boolean),
    },
    take: 50,
    orderBy: { rating: "desc" },
  });

  res.status(200).json(contractors);
}
