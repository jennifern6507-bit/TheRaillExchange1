import { buffer } from 'micro'
import { prisma } from '../../../lib/prisma'
import { stripe } from '../../../lib/stripe'

export const config = { api: { bodyParser: false } }

export default async function handler(req, res) {
  const sig = req.headers['stripe-signature']
  const raw = await buffer(req)
  let event
  try {
    event = stripe.webhooks.constructEvent(raw, sig!, process.env.STRIPE_WEBHOOK_SECRET!)
  } catch (err) {
    console.error(err)
    return res.status(400).send(`Webhook Error: ${err.message}`)
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object
    // store subscription - find user by email and persist subscription info
    const customerEmail = session.customer_details?.email
    if (customerEmail) {
      const user = await prisma.user.findUnique({ where: { email: customerEmail } })
      if (user) {
        await prisma.subscription.create({ data: { userId: user.id, stripeId: session.subscription as string, plan: 'unknown', status: 'active' } })
      }
    }
  }

  if (event.type === 'invoice.payment_succeeded') {
    // handle
  }

  res.json({ received: true })
}
