\'use client\'
import { useState } from 'react'
import axios from 'axios'

export default function BidForm({ projectId }: { projectId: string }) {
  const [amount, setAmount] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    try {
      await axios.post('/api/bids', { projectId, amount: Number(amount), notes })
      alert('Bid submitted')
      setAmount('')
      setNotes('')
    } catch (err) {
      alert('Error submitting bid')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={submit} className="mt-3 space-y-3">
      <input value={amount} onChange={e => setAmount(e.target.value)} placeholder="Amount (USD)" className="w-full p-3 border rounded" />
      <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notes, scope, timeline" className="w-full p-3 border rounded" />
      <button disabled={loading} type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded">
        {loading ? 'Sending...' : 'Submit Bid'}
      </button>
    </form>
  )
}
